<?php get_header(); ?>

<main class="main-background error404" style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/roki-fundo.jpg)">
        <div class="container"> 
            <div class="row">
                <div class="row-h1">
                    <h1>
                        Error 404: Page not found.
                    </h1>
                </div>   
            </div>
        </div>   
    </main>

<?php get_footer(); ?>